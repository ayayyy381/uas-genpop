Web Belajar UAS — Final (Ultimate Extreme)
========================================

Files prepared for Vercel deployment (React + Vite + Tailwind basic setup).

How to deploy:
1. Install Node.js (if testing locally).
2. Upload this folder to Vercel or GitHub and connect to Vercel.
3. On Vercel, choose Import Project -> Select 'Upload' and drag this folder (or zip).
4. Build command: `npm run build` (Vercel will run automatically).

Notes:
- Illustrations are simple placeholders extracted/created automatically. If you want original diagrams extracted from PDFs as high-quality images, tell me and I'll attempt a PDF extraction process.
