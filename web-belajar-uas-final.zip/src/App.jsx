
import React from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import HomePage from './pages/Home.jsx'
import IsolationPage from './pages/Isolation.jsx'
import BlastPage from './pages/Blast.jsx'
import GenVarPage from './pages/GenVar.jsx'
import OneHourPage from './pages/OneHour.jsx'
import FlashcardPage from './pages/Flashcard.jsx'

export default function App(){
  return (
    <Router>
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-5xl mx-auto">
          <nav className="flex gap-4 text-lg font-medium mb-6">
            <Link to="/" className="text-sky-600">Beranda</Link>
            <Link to="/isolation" className="text-sky-600">Isolation & Speciation</Link>
            <Link to="/blast" className="text-sky-600">BLAST & GeneStudio</Link>
            <Link to="/genetic-variation" className="text-sky-600">Genetic Variation</Link>
            <Link to="/one-hour" className="text-sky-600">Belajar 1 Jam</Link>
            <Link to="/flashcards" className="text-sky-600">Flashcards</Link>
          </nav>

          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/isolation" element={<IsolationPage />} />
            <Route path="/blast" element={<BlastPage />} />
            <Route path="/genetic-variation" element={<GenVarPage />} />
            <Route path="/one-hour" element={<OneHourPage />} />
            <Route path="/flashcards" element={<FlashcardPage />} />
          </Routes>
        </div>
      </div>
    </Router>
  )
}
