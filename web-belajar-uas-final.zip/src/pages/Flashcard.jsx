import React from 'react'
export default function FlashcardPage(){
  const cards = [
    {q: "Apa itu isolasi temporal?", a: "Perbedaan waktu kawin yang mencegah interaksi reproduktif."},
    {q: "Apa itu hybrid sterility?", a: "Hibrida yang hidup tetapi steril, contoh mule."},
    {q: "Apa % identity di BLAST?", a: "Persentase basa/AA yang identik pada alignment."},
    {q: "SNP vs microsatellite?", a: "SNP = single-base variant; microsatellite = short tandem repeat."}
  ]
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Flashcards</h1>
      <div className="grid md:grid-cols-2 gap-4 mt-4">
        {cards.map((c,i)=>(<div key={i} className="p-4 border rounded bg-white shadow"><b>{c.q}</b><p className="mt-2 text-sm">{c.a}</p></div>))}
      </div>
    </div>
  )
}
