import React from 'react'
export default function OneHourPage(){
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Belajar 1 Jam — Super Ringkas</h1>
      <div className="mt-4 grid md:grid-cols-2 gap-4">
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">Isolation & Speciation</h3>
          <ul className="list-disc ml-5">
            <li>Pra-zigot vs pasca-zigot</li>
            <li>Allopatric paling sering</li>
            <li>Poliploidi = spesiasi cepat pada tumbuhan</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">BLAST & GeneStudio</h3>
          <ul className="list-disc ml-5">
            <li>BLASTn: periksa identity & coverage</li>
            <li>Clean sequence sebelum BLAST</li>
            <li>Gunakan BOLD untuk COI</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">Genetic Variation</h3>
          <ul className="list-disc ml-5">
            <li>SNPs & microsatellites untuk populasi</li>
            <li>Heritability menentukan respons seleksi</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">Tips UAS</h3>
          <ul className="list-disc ml-5">
            <li>Fokus definisi & perbedaan (contoh: pra vs pasca)</li>
            <li>Ingat contoh nyata (kuda × keledai, poliploidi)</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
