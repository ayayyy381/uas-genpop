import React from 'react'
export default function HomePage(){
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-2">Web Belajar UAS</h1>
      <p className="text-gray-700">Kumpulan materi lengkap untuk persiapan UAS: Isolation & Speciation, BLAST/GeneStudio, Genetic Variation. Gunakan navbar untuk navigasi.</p>
    </div>
  )
}
