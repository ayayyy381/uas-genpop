import React from 'react'
export default function GenVarPage(){
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Genetic Variation: Quantitative, Molecular, Chromosome</h1>

      <section>
        <h2 className="text-xl font-semibold">1. Quantitative Variation</h2>
        <p>Traits controlled by many genes produce continuous variation. Heritability (H) = G / D (as taught in slides).</p>
        <img src="/illustrations/quantitative.png" alt="Quantitative distribution" className="w-full rounded shadow" />
      </section>

      <section>
        <h2 className="text-xl font-semibold">2. Molecular Variation</h2>
        <p>SNPs, microsatellites, haplotypes, RFLP, allozyme. Gunakan marker sesuai tujuan (resolusi/populasi).</p>
        <img src="/illustrations/molecular.png" alt="Molecular" className="w-full rounded shadow" />
      </section>

      <section>
        <h2 className="text-xl font-semibold">3. Chromosome Variation</h2>
        <p>Perubahan jumlah/struktur kromosom memengaruhi fertlity & speciation. Contoh banding, karyotype analysis.</p>
        <img src="/illustrations/chromosome.png" alt="Chromosome" className="w-full rounded shadow" />
      </section>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🔎 Ringkasan Cepat</h3>
          <ul className="list-disc ml-5 mt-2">
            <li>SNPs untuk resolusi tinggi, microsatellites untuk populasi.</li>
            <li>Poliploidi umum pada tumbuhan sebagai mekanisme spesiasi cepat.</li>
            <li>Gunakan software: MEGA, GENALEX, STRUCTURE untuk analisis.</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🧠 Mini Quiz</h3>
          <ol className="list-decimal ml-5 mt-2">
            <li>Apa itu heterozygosity?</li>
            <li>Berikan 2 contoh marker molekuler.</li>
            <li>Mengapa karyotype penting dalam taksonomi?</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
