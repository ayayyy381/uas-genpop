import React from 'react'
export default function IsolationPage(){
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Isolation Mechanisms & Speciation</h1>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">1. Prezygotic Isolation</h2>
        <p>Prezygotic barriers mencegah terjadinya fertilisasi. Termasuk isolasi habitat, temporal, perilaku, mekanik, dan gametik.</p>
        <ul className="list-disc ml-6 space-y-1">
          <li><b>Habitat isolation:</b> Populasi menempati niche berbeda → jarang kontak.</li>
          <li><b>Temporal isolation:</b> Waktu reproduksi tidak sinkron.</li>
          <li><b>Behavioral isolation:</b> Sinyal/ritual kawin berbeda → gagal pengenalan.</li>
          <li><b>Mechanical isolation:</b> Struktur genital tidak kompatibel.</li>
          <li><b>Gametic isolation:</b> Gamet tidak terspesialisasi untuk fertilisasi silang.</li>
        </ul>
        <img src="/illustrations/isolation.png" alt="Isolation diagram" className="w-full rounded shadow" />
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">2. Postzygotic Isolation</h2>
        <p>Barier yang bekerja setelah fertilisasi terjadi.</p>
        <ul className="list-disc ml-6 space-y-1">
          <li><b>Hybrid inviability:</b> Zigot gagal berkembang.</li>
          <li><b>Hybrid sterility:</b> Hibrida infertil (contoh: kuda × keledai → mule).</li>
          <li><b>Hybrid breakdown:</b> Generasi F2 mengalami penurunan fitness.</li>
        </ul>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">3. Modes of Speciation</h2>
        <ul className="list-disc ml-6 space-y-1">
          <li><b>Allopatric speciation:</b> Terbentuk karena isolasi geografis total.</li>
          <li><b>Peripatric speciation:</b> Subpopulasi kecil terisolasi → efek founder.</li>
          <li><b>Parapatric speciation:</b> Kontak terbatas → hybrid zone.</li>
          <li><b>Sympatric speciation:</b> Tanpa pemisahan geografis (mis: poliploidi tanaman).</li>
          <li><b>Quantum speciation:</b> Perubahan cepat akibat rearrangement kromosom.</li>
        </ul>
      </section>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🔎 Ringkasan Cepat</h3>
          <ul className="list-disc ml-5 mt-2">
            <li>Pra-zigot mencegah fertilisasi; pasca-zigot bekerja setelah fertilisasi.</li>
            <li>Spesiasi paling sering terjadi allopatrik pada isolasi geografis.</li>
            <li>Poliploidi adalah jalan cepat spesiasi di tumbuhan (sympatrik).</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🧠 Mini Quiz</h3>
          <ol className="list-decimal ml-5 mt-2">
            <li>Sebutkan 3 contoh isolasi pra-zigot.</li>
            <li>Apa perbedaan peripatric & parapatric?</li>
            <li>Berikan satu contoh hybrid sterility.</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
