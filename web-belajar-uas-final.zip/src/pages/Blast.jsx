import React from 'react'
export default function BlastPage(){
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Tutorial GeneStudio, BLAST, & Identification Engine</h1>

      <section>
        <h2 className="text-xl font-semibold">1. Pengolahan Kromatogram (GeneStudio)</h2>
        <p>Import file .ab1 → periksa forward/reverse → hapus peak buruk → edit basa ambigu → buat consensus.</p>
        <img src="/illustrations/blast.png" alt="BLAST workflow" className="w-full rounded shadow" />
      </section>

      <section>
        <h2 className="text-xl font-semibold">2. Validasi CDS</h2>
        <p>Translasi untuk cek stop codon. Pastikan frame benar dan tidak ada '*' di tengah CDS.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold">3. BLASTn & Interpretasi</h2>
        <ul className="list-disc ml-6">
          <li>% identity: seberapa mirip</li>
          <li>Coverage: seberapa banyak sekuens yang tercover</li>
          <li>E-value: signifikansi alignment</li>
        </ul>
      </section>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🔎 Ringkasan Cepat</h3>
          <ul className="list-disc ml-5 mt-2">
            <li>BLASTn untuk identifikasi gen/organisme.</li>
            <li>Periksa identity & coverage, jangan hanya E-value.</li>
            <li>Gunakan BOLD untuk barcode COI.</li>
          </ul>
        </div>
        <div className="p-4 border rounded bg-white shadow">
          <h3 className="font-semibold">🧠 Mini Quiz</h3>
          <ol className="list-decimal ml-5 mt-2">
            <li>Apa arti % identity di hasil BLAST?</li>
            <li>Kapan menggunakan BOLD vs NCBI BLAST?</li>
            <li>Apa yang harus dilakukan jika sequence memiliki banyak N?</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
